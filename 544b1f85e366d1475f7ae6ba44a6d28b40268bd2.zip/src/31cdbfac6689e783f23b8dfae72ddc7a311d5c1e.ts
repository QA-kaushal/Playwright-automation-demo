import { Page, Locator, expect } from '@playwright/test';
export class LoginPage {
    readonly page: Page;
    readonly inputEmail: Locator;
    readonly inputPassword: Locator;
    readonly loginButton: Locator;
    readonly btnSignOut: Locator;



    constructor(page: Page) {
        this.page = page;
        this.inputEmail = page.locator("input[type='email']");
        this.inputPassword = page.locator("input[type='password']");
        this.loginButton = page.locator("input[type='submit']");
        this.btnSignOut = page.locator("//button[normalize-space(text())='Sign Out']");

    }


    async loginTotheApplication(username: string, password: string) {
        await this.navigateToUrl();

        await this.inputEmail.pressSequentially(username, { delay: 100 });
        await this.inputPassword.pressSequentially(password, { delay: 100 });
        await this.loginButton.click();

        await expect(this.btnSignOut).toBeVisible();

    }



    private async navigateToUrl() {
        await this.page.goto('https://rahulshettyacademy.com/client');

    }





}

