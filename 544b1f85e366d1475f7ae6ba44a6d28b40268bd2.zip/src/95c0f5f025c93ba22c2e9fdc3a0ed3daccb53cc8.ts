import { Locator, Page, expect } from "@playwright/test";


export class DashboardPage {
    readonly page: Page;
    readonly toastMsgProductAddedToCart: Locator;
    readonly products: Locator;
    readonly btnCart: Locator;


    constructor(page: Page) {
        this.page = page;
        this.products = page.locator("div[class='row'] b");
        this.toastMsgProductAddedToCart = page.locator("//div[@aria-label='Product Added To Cart']");
        this.btnCart = page.locator("button[routerlink='/dashboard/cart']");
    }

    async addProductsTocart(productNames: any) {
        console.log(await this.products.allTextContents());
        for (const productName of productNames) {
            const productAddToCart = this.page.locator(`//b[text()='${productName}']/parent::h5/following-sibling::button[normalize-space(text())='Add To Cart']`);
            await productAddToCart.evaluate((el) => {
                (el as HTMLElement).style.outline = '4px dotted gold';
            });
            await productAddToCart.click();
            await expect(this.toastMsgProductAddedToCart).toBeVisible();

        }

        await this.btnCart.click();
    }


}