import { test, expect } from '@playwright/test';
import { LoginPage } from '../pageobjects/LoginPage';
import { DashboardPage } from '../pageobjects/DashboardPage';
import { CartPage } from '../pageobjects/CartPage';
import { PaymentPage } from '../pageobjects/PaymentPage';
import { DeleteOrdersFromOrders } from '../pageobjects/DeleteOrdersFromOrders';


test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.loginTotheApplication("radhapatil96@gmail.com", "Radha@123");
});

test('first playwright test', async ({ page }) => {
    const productNames = ["iphone 13 pro", "ZARA COAT 3", "ADIDAS ORIGINAL"];
    const countryName = "India";

    const dashboardPage = new DashboardPage(page);
    const cartpage = new CartPage(page);
    const paymentPage = new PaymentPage(page);
    const deleteOrdersFromOders = new DeleteOrdersFromOrders(page);
    await dashboardPage.addProductsTocart(productNames);
    await cartpage.checkoutOrders();
    await paymentPage.payForSelectedProducts(countryName);
    await deleteOrdersFromOders.deleteOrders();

});





