import { Page, expect, Locator } from "@playwright/test";


export class CartPage {
    readonly btnCheckout: Locator;

    constructor(page: Page) {
        this.btnCheckout = page.locator("//button[text()='Checkout']");
    }

    async checkoutOrders() {
        await expect(this.btnCheckout).toBeVisible();
        await this.btnCheckout.click();
    }

}