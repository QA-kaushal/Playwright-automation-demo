import { expect, Locator, Page } from "@playwright/test";


export class PaymentPage {

    readonly page: Page;
    readonly paymentPageTitle: Locator;
    readonly inputCountryName: Locator;
    readonly btnPlaceOrder: Locator;
    readonly tabOrders: Locator;

    constructor(page: Page) {
        this.page = page;
        this.paymentPageTitle = page.locator("//div[normalize-space(text())='Payment Method']");
        this.inputCountryName = page.locator("//input[@placeholder='Select Country']");
        this.btnPlaceOrder = page.locator("//a[normalize-space(text())='Place Order']");
        this.tabOrders = page.locator("//button[contains(text(),'ORDERS')]");

    }

    async payForSelectedProducts(countryName: string) {
        await expect(this.paymentPageTitle).toBeVisible();
        console.log(await this.paymentPageTitle.textContent());

        await this.inputCountryName.pressSequentially(`${countryName}`, { delay: 100 });
        await this.page.locator(`//button/descendant::span[normalize-space(text())='${countryName}']`).click();
        await this.btnPlaceOrder.click();
        await expect(this.tabOrders).toBeVisible();
    }
}