import { expect, Locator, Page } from "@playwright/test";

export class DeleteOrdersFromOrders {
    readonly page: Page;
    readonly toastMsgOrderesDeleted: Locator;
    readonly tabOrders: Locator;
    readonly btnGoBackToShope: Locator;
    readonly cartItemsIds: Locator;
    readonly btnSignOut: Locator;

    constructor(page: Page) {
        this.page = page;
        this.toastMsgOrderesDeleted = page.locator("//div[@aria-label='Orders Deleted Successfully']");
        this.cartItemsIds = page.locator("//tr[@class='ng-star-inserted']/descendant::label");
        this.tabOrders = page.locator("//button[contains(text(),'ORDERS')]");
        this.btnGoBackToShope = page.locator("//button[text()='Go Back to Shop']");
        this.btnSignOut = page.locator("//button[normalize-space(text())='Sign Out']");

    }

    async deleteOrders() {
        const itemIds = await this.productsIdes();
       

        await this.tabOrders.click();

        for (const itemId of itemIds) {
            await console.log("item to be deleted : " + itemId);
            const deleteFromOrdersTab = await this.page.locator(`//th[text()='${itemId.replaceAll("|", "").trim()}']/parent::tr/descendant::button[text()='Delete']`);
            await expect(deleteFromOrdersTab).toBeVisible();
            await deleteFromOrdersTab.scrollIntoViewIfNeeded();
            await deleteFromOrdersTab.evaluate((el) => {
                (el as HTMLElement).style.outline = '4px dotted gold';
            });
            await this.page.waitForTimeout(1000);
            await deleteFromOrdersTab.click();
            await expect(this.toastMsgOrderesDeleted).toBeHidden();
            await this.page.waitForTimeout(2000);


        }

        await expect(this.btnGoBackToShope).toBeVisible();
        await this.btnGoBackToShope.click();
        await expect(this.btnSignOut).toBeVisible();


    }


    private async productsIdes(): Promise<string[]> {
        await expect(this.cartItemsIds.nth(0)).toBeVisible();
        return await this.cartItemsIds.allTextContents();

    }



}